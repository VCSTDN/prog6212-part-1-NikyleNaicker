﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG2B_2023.Model
{
    internal class Module
    {
        //Contains the 
        public string ModuleCode { get; set; }
        public string ModuleName { get; set; }
        public int Credits { get; set; }
        public int Classhours { get; set; }
    }
}
