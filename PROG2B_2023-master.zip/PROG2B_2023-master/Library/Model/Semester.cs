﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG2B_2023.Model
{
    class Semester
    {
        public DateTime SemesterDate { get; set; }
        public int NumWeeks { get; set; }
    }
}
