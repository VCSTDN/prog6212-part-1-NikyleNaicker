﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG2B_2023.Model
{
    internal class Record
    {
        public string ModuleName2 { get; set; }
        public int Credits2 { get; set; }
        public int Classhours2 { get; set; }
        public int NumWeeks2 { get; set; }
        public int Num_of_hours_studied { get; set; }
        public int week_study_hours { get; set; }
    }
}
